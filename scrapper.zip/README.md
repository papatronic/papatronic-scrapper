# Papatronic Scrapper

## About this project

> Project description shall be added here hen available

### Tools, frameworks, libraries and specifications used in the making of this project

> Specific versions used for each library can be found in the package.json

* [Cheerio](https://cheerio.js.org/)

* [node-postgres](https://node-postgres.com/)

* [node-schedule](https://github.com/node-schedule/node-schedule)

* [request-promise](https://github.com/request/request-promise)

* [Eslint](https://eslint.org/)

* [Moment.js](https://momentjs.com/)

* [Winston](https://github.com/winstonjs/winston)

### Notes

> Use npm ci to install dependencies. That's why the package-lock is included.